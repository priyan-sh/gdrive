PCOD Xpert by Hope - Asset Pack
01_Logos            Full logo and butterfly-only (transparent PNG, white, white-on-purple)
02_Social_Media     Profile pictures (1080/640), square posts, Facebook/X/LinkedIn/YouTube banners, Instagram story
03/04 Illustrations Booklet graphics (English / Hindi), transparent PNG, high resolution
05/06 Booklet pages Every booklet page as a PNG (150 dpi) - use for carousel posts
07_Covers_and_QR    Booklet covers and WhatsApp QR code (+91 82230 87999)
Brand colours: Purple #A62683, Light Purple #624E88, Pink #F29BAA. Font: Poppins.
